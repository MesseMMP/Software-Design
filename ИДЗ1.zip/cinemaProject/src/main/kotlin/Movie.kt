package org.example

import kotlinx.serialization.Serializable

/**
 * Класс `Movie` представляет собой фильм в кинотеатре.
 *
 * @property id Уникальный идентификатор фильма.
 * @property title Название фильма.
 * @property duration Продолжительность фильма в минутах.
 * @property genre Жанр фильма.
 */
@Serializable
class Movie(val id: Int, var title: String, var duration: Int, var genre: String) {
    override fun toString(): String {
        return "Movie(id=$id, title='$title', duration=$duration, genre='$genre')"
    }
}

/**
 * Класс `MovieManager` отвечает за управление фильмами в системе кинотеатра.
 *
 * @property database Инстанс базы данных, содержащий данные о пользователях, фильмах,
 * сеансах и билетах.
 */
class MovieManager(private val database: Database) {
    /**
     * Метод `addMovie` добавляет новый фильм в систему.
     *
     * @param title Название фильма.
     * @param duration Продолжительность фильма в минутах.
     * @param genre Жанр фильма.
     */
    fun addMovie(title: String, duration: Int, genre: String) {
        if (title.isNotBlank() && genre.isNotBlank() && duration > 0) {
            val existingMovie = database.movies.find { it.title == title }
            if (existingMovie == null) {
                val id = database.movieIdCounter++
                database.movies.add(Movie(id, title, duration, genre))
                println("Фильм успешно добавлен!")
            } else {
                println("Фильм с названием '$title' уже существует!")
            }
        } else {
            println("Название и жанр фильма не должны быть пустыми, а сам фильм должен идти хотя бы 1 минуту!")
        }
    }

    /**
     * Метод `editMovie` изменяет данные о фильме по его ID.
     *
     * @param movieId ID фильма.
     * @param title Новое название фильма.
     * @param duration Новая продолжительность фильма в минутах.
     * @param genre Новый жанр фильма.
     */
    fun editMovie(movieId: Int, title: String, duration: Int, genre: String) {
        val movie = database.movies.find { it.id == movieId }
        if (movie != null) {
            if (title.isNotBlank() && genre.isNotBlank() && duration > 0) {
                movie.title = title
                movie.duration = duration
                movie.genre = genre
                println("Данные фильма успешно обновлены!")
            } else {
                println("Ошибка! Название и жанр фильма не должны быть пустыми, а сам фильм должен идти хотя бы 1 минуту!")
            }
        } else {
            println("Фильм с ID $movieId не найден!")
        }
    }
}
