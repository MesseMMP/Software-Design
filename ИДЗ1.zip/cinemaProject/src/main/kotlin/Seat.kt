package org.example

import kotlinx.serialization.Serializable

/**
 * Класс `Seat` представляет собой место в кинозале, которое может быть свободным или занятым.
 *
 * @property id Идентификатор места.
 * @property isOccupied Флаг, указывающий, занято ли место.
 */
@Serializable
class Seat(val id: Int, var isOccupied: Boolean = false) {
    /**
     * Красивый вывод мест в консоль, занято - красным, свободно - зеленым
     */
    override fun toString(): String {
        return if (isOccupied) "\u001B[31m${
            String.format(
                " <%02d> ",
                id
            )
        }\u001B[0m" else "\u001B[32m${String.format(" <%02d> ", id)}\u001B[0m"
    }
}
