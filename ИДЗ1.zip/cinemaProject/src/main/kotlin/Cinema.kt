package org.example

import kotlinx.datetime.LocalDateTime

/**
 * Класс `Cinema` представляет собой основной компонент системы кинотеатра, объединяющий
 * функциональность управления пользователями, фильмами, сеансами и билетами.
 *
 * @property userManager Менеджер пользователей для управления пользователями в системе.
 * @property movieManager Менеджер фильмов для управления фильмами в системе.
 * @property sessionManager Менеджер сеансов для управления сеансами в системе.
 * @property ticketManager Менеджер билетов для управления билетами в системе.
 * @property dataManager Менеджер данных для сохранения и загрузки данных из файлов.
 */
class Cinema(database: Database) {
    private val userManager = UserManager(database)
    private val movieManager = MovieManager(database)
    private val sessionManager = SessionManager(database)
    private val ticketManager = TicketManager(database)
    private val dataManager = DataManager(database)

    /**
     * Метод `registerUser` регистрирует нового пользователя в системе.
     *
     * @param username Имя пользователя.
     * @param password Пароль пользователя.
     */
    fun registerUser(username: String, password: String) {
        userManager.registerUser(username, password)
    }

    /**
     * Метод `loginUser` осуществляет вход пользователя в систему.
     *
     * @param username Имя пользователя.
     * @param password Пароль пользователя.
     * @return `true`, если вход успешен, и `false` в противном случае.
     */
    fun loginUser(username: String, password: String): Boolean {
        return userManager.loginUser(username, password)
    }

    /**
     * Метод `sellTicket` выполняет продажу билета на указанный сеанс и место.
     *
     * @param sessionId ID сеанса.
     * @param seatId ID места.
     */
    fun sellTicket(sessionId: Int, seatId: Int) {
        ticketManager.sellTicket(sessionId, seatId)
    }

    /**
     * Метод `returnTicket` выполняет возврат билета по его ID.
     *
     * @param ticketId ID билета.
     */
    fun returnTicket(ticketId: Int) {
        ticketManager.returnTicket(ticketId)
    }

    /**
     * Метод `addMovie` добавляет новый фильм в систему.
     *
     * @param title Название фильма.
     * @param duration Продолжительность фильма в минутах.
     * @param genre Жанр фильма.
     */
    fun addMovie(title: String, duration: Int, genre: String) {
        movieManager.addMovie(title, duration, genre)
    }

    /**
     * Метод `editMovie` изменяет данные о фильме по его ID.
     *
     * @param movieId ID фильма.
     * @param title Новое название фильма.
     * @param duration Новая продолжительность фильма в минутах.
     * @param genre Новый жанр фильма.
     */
    fun editMovie(movieId: Int, title: String, duration: Int, genre: String) {
        movieManager.editMovie(movieId, title, duration, genre)
    }

    /**
     * Метод `addSession` добавляет новый сеанс по ID фильма и времени начала.
     *
     * @param movieId ID фильма.
     * @param startTime Время начала сеанса.
     */
    fun addSession(movieId: Int, startTime: LocalDateTime) {
        sessionManager.addSession(movieId, startTime)
    }

    /**
     * Метод `editSession` изменяет данные о сеансе по его ID.
     *
     * @param sessionId ID сеанса.
     * @param movieId Новый ID фильма.
     * @param startTime Новое время начала сеанса.
     * @param endTime Новое время окончания сеанса.
     */
    fun editSession(sessionId: Int, movieId: Int, startTime: LocalDateTime, endTime: LocalDateTime) {
        sessionManager.editSession(sessionId, movieId, startTime, endTime)
    }

    /**
     * Метод `displayAvailableSeats` выводит список свободных мест на указанном сеансе.
     *
     * @param sessionId ID сеанса.
     */
    fun displayAvailableSeats(sessionId: Int) {
        sessionManager.displayAvailableSeats(sessionId)
    }

    /**
     * Метод `saveMovies` сохраняет данные о фильмах в файл.
     */
    fun saveMovies() {
        dataManager.saveMovies()
    }

    /**
     * Метод `loadMovies` загружает данные о фильмах из файла.
     */
    fun loadMovies() {
        dataManager.loadMovies()
    }

    /**
     * Метод `saveSessions` сохраняет данные о сеансах в файл.
     */
    fun saveSessions() {
        dataManager.saveSessions()
    }

    /**
     * Метод `loadSessions` загружает данные о сеансах из файла.
     */
    fun loadSessions() {
        dataManager.loadSessions()
    }

    /**
     * Метод `saveTickets` сохраняет данные о билетах в файл.
     */
    fun saveTickets() {
        dataManager.saveTickets()
    }

    /**
     * Метод `loadTickets` загружает данные о билетах из файла.
     */
    fun loadTickets() {
        dataManager.loadTickets()
    }

    /**
     * Метод `saveUsers` сохраняет данные о пользователях в файл.
     */
    fun saveUsers() {
        dataManager.saveUsers()
    }

    /**
     * Метод `loadUsers` загружает данные о пользователях из файла.
     */
    fun loadUsers() {
        dataManager.loadUsers()
    }
}
