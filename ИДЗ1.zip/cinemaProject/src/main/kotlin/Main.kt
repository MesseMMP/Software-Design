package org.example

/**
 * Основная функция `main` запускает приложение кинотеатра.
 * Создается экземпляр базы данных `Database` и передается в конструктор
 * класса `CinemaApplication`, после чего вызывается метод `run` для запуска
 * основного цикла работы приложения.
*/
fun main() {
    val database = Database()
    val cinemaApp = CinemaApplication(database)
    cinemaApp.run()
}
