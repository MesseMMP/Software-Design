package org.example

import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.nio.file.Files
import java.nio.file.Path

/**
 * Класс `Database` представляет собой хранилище данных системы кинотеатра.
 *
 * @property users Список пользователей.
 * @property movies Список фильмов.
 * @property sessions Список сеансов.
 * @property tickets Список билетов.
 * @property userIdCounter Счетчик идентификаторов пользователей.
 * @property movieIdCounter Счетчик идентификаторов фильмов.
 * @property sessionIdCounter Счетчик идентификаторов сеансов.
 * @property ticketIdCounter Счетчик идентификаторов билетов.
 */
class Database {
    val users: MutableList<User> = mutableListOf()
    val movies: MutableList<Movie> = mutableListOf()
    val sessions: MutableList<Session> = mutableListOf()
    val tickets: MutableList<Ticket> = mutableListOf()

    var userIdCounter: Int = 0

    var movieIdCounter: Int = 0

    var sessionIdCounter: Int = 0

    var ticketIdCounter: Int = 0
}

/**
 * Класс `DataManager` управляет сохранением и загрузкой данных в/из файлов.
 *
 * @property database База данных, содержащая списки пользователей, билетов, сеансов и фильмов.
 */
class DataManager(private val database: Database) {
    /**
     * Метод `saveMovies` сохраняет данные о фильмах в файл.
     */
    fun saveMovies() {
        val json = Json.encodeToString(database.movies)
        File("movies.json").writeText(json)
    }

    /**
     * Метод `loadMovies` загружает данные о фильмах из файла.
     */
    fun loadMovies() {
        try {
            val json = Files.readString(Path.of("movies.json"))
            database.movies.addAll(Json.decodeFromString(json))
            if (database.movies.isNotEmpty()) {
                database.movieIdCounter = database.movies.maxOf { movie -> movie.id } + 1
            }
        } catch (e: Exception) {
            println("Ошибка при загрузке данных о фильмах: ${e.message}")
        }
    }

    /**
     * Метод `saveSessions` сохраняет данные о сеансах в файл.
     */
    fun saveSessions() {
        val json = Json.encodeToString(database.sessions)
        File("sessions.json").writeText(json)
    }

    /**
     * Метод `loadSessions` загружает данные о сеансах из файла.
     */
    fun loadSessions() {
        try {
            val json = Files.readString(Path.of("sessions.json"))
            database.sessions.addAll(Json.decodeFromString(json))
            if (database.sessions.isNotEmpty()) {
                database.sessionIdCounter = database.sessions.maxOf { session -> session.id } + 1
            }
        } catch (e: Exception) {
            println("Ошибка при загрузке данных о сеансах: ${e.message}")
        }
    }

    /**
     * Метод `saveTickets` сохраняет данные о билетах в файл.
     */
    fun saveTickets() {
        val json = Json.encodeToString(database.tickets)
        File("tickets.json").writeText(json)
    }

    /**
     * Метод `loadTickets` загружает данные о билетах из файла.
     */
    fun loadTickets() {
        try {
            val json = Files.readString(Path.of("tickets.json"))
            database.tickets.addAll(Json.decodeFromString(json))
            if (database.tickets.isNotEmpty()) {
                database.ticketIdCounter = database.tickets.maxOf { ticket -> ticket.id } + 1
            }
        } catch (e: Exception) {
            println("Ошибка при загрузке данных о билетах: ${e.message}")
        }
    }

    /**
     * Метод `saveUsers` сохраняет данные о пользователях в файл.
     */
    fun saveUsers() {
        val json = Json.encodeToString(database.users)
        File("users.json").writeText(json)
    }

    /**
     * Метод `loadUsers` загружает данные о пользователях из файла.
     */
    fun loadUsers() {
        try {
            val json = Files.readString(Path.of("users.json"))
            database.users.addAll(Json.decodeFromString(json))
            if (database.users.isNotEmpty()) {
                database.userIdCounter = database.users.maxOf { user -> user.id } + 1
            }
        } catch (e: Exception) {
            println("Ошибка при загрузке данных о пользователях: ${e.message}")
        }
    }
}
