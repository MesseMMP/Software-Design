package org.example

import kotlinx.serialization.Serializable
import java.security.MessageDigest

/**
 * Класс User представляет собой пользователя системы кинотеатра.
 *
 * @property id Идентификатор пользователя.
 * @property username Имя пользователя.
 * @property encryptedPassword Зашифрованный пароль пользователя.
 */
@Serializable
class User(val id: Int, val username: String, var encryptedPassword: String) {
}

/**
 * Класс UserManager управляет регистрацией и входом пользователей в систему.
 *
 * @property database База данных, содержащая списки пользователей, билетов, сеансов и фильмов.
 */
class UserManager(private val database: Database) {
    /**
     * Метод registerUser регистрирует нового пользователя в системе.
     *
     * @param username Имя пользователя.
     * @param password Пароль пользователя.
     */
    fun registerUser(username: String, password: String) {
        val existingUser = database.users.find { it.username == username }
        if (existingUser == null) {
            val id = database.userIdCounter++
            database.users.add(User(id, username, hashPassword(password)))
            println("Пользователь успешно зарегистрирован!")
        } else {
            println("Пользователь с таким именем уже существует!")
        }
    }

    /**
     * Метод loginUser выполняет вход пользователя в систему.
     *
     * @param username Имя пользователя.
     * @param password Пароль пользователя.
     * @return true, если вход выполнен успешно, иначе false.
     */
    fun loginUser(username: String, password: String): Boolean {
        val user = database.users.find { it.username == username }
        if (user != null) {
            return checkPassword(password, user.encryptedPassword)
        }
        return false;
    }

    /**
     * Шифрует пароль с использованием алгоритма SHA-256.
     *
     * @param password Пароль, который необходимо зашифровать.
     * @return Зашифрованный пароль в виде строки.
     */
    private fun hashPassword(password: String): String {
        val digestBytes = MessageDigest.getInstance("SHA-256").digest(password.toByteArray())
        return digestBytes.joinToString("") { "%02x".format(it) }
    }

    /**
     * Проверяет, соответствует ли введенный пароль хранимому хэшу.
     *
     * @param inputPassword Введенный пользователем пароль.
     * @param encryptedPassword Зашифрованный пароль, сохраненный в базе данных.
     * @return true, если пароли совпадают, иначе false.
     */
    private fun checkPassword(inputPassword: String, encryptedPassword: String): Boolean {
        return hashPassword(inputPassword) == encryptedPassword
    }
}
