package org.example

import kotlinx.datetime.toKotlinLocalDateTime
import kotlinx.serialization.Serializable

/**
 * Класс `Ticket` представляет собой билет на сеанс кинотеатра.
 *
 * @property id Уникальный идентификатор билета.
 * @property sessionId ID сеанса, на который приобретен билет.
 * @property seatId ID места, на которое приобретен билет.
 */
@Serializable
class Ticket(val id: Int, val sessionId: Int, val seatId: Int) {
    override fun toString(): String {
        return "Ticket(id=$id, sessionId=$sessionId, seatId=$seatId)"
    }
}

/**
 * Класс `TicketManager` отвечает за управление билетами в системе кинотеатра.
 *
 * @property database Инстанс базы данных, содержащий данные о пользователях, фильмах,
 * сеансах и билетах.
 */
class TicketManager(private val database: Database) {

    /**
     * Метод `sellTicket` выполняет продажу билета на указанный сеанс и место.
     *
     * @param sessionId ID сеанса.
     * @param seatId ID места.
     */
    fun sellTicket(sessionId: Int, seatId: Int) {
        val session = database.sessions.find { it.id == sessionId }
        val seat = session?.availableSeats?.find { it.id == seatId && !it.isOccupied }
        if (session != null && seat != null) {
            if (java.time.LocalDateTime.now().toKotlinLocalDateTime() > session.startTime) {
                println("Сеанс уже начался! Продажа билета невозможена!")
            } else {
                val ticketId = database.ticketIdCounter++
                database.tickets.add(Ticket(ticketId, sessionId, seatId))
                seat.isOccupied = true
                println("Билет успешно продан!")
            }
        } else {
            println("Некорректные значения ID сеанса или места!")
        }
    }

    /**
     * Метод `returnTicket` выполняет возврат билета по его ID.
     *
     * @param ticketId ID билета.
     */
    fun returnTicket(ticketId: Int) {
        val ticket = database.tickets.find { it.id == ticketId }
        val session = database.sessions.find { it.id == ticket?.sessionId }
        val seat = session?.availableSeats?.find { it.id == ticket?.seatId }
        if (ticket != null && session != null && seat != null) {
            if (java.time.LocalDateTime.now().toKotlinLocalDateTime() > session.startTime) {
                println("Сеанс уже начался! Возврат билета невозможен!")
            } else {
                database.tickets.remove(ticket)
                seat.isOccupied = false
                println("Билет успешно возвращен!")
            }
        } else {
            println("Данные билета указаны неверно!")
        }
    }
}
