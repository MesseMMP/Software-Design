package org.example

import kotlinx.datetime.LocalDateTime
import kotlinx.datetime.toJavaLocalDateTime
import kotlinx.datetime.toKotlinLocalDateTime
import kotlinx.serialization.Serializable

/**
 * Класс `Session` представляет информацию о сеансе в кинотеатре.
 *
 * @property id Уникальный идентификатор сеанса.
 * @property movieId Идентификатор фильма, связанного с сеансом.
 * @property startTime Время начала сеанса.
 * @property endTime Время окончания сеанса.
 * @property availableSeats Список доступных мест на сеансе.
 * @property visitors Список идентификаторов посетителей, занявших места.
 */
@Serializable
class Session(
    val id: Int,
    var movieId: Int,
    var startTime: LocalDateTime,
    var endTime: LocalDateTime,
    var availableSeats: MutableList<Seat>,
    val visitors: MutableList<Int> = mutableListOf(), // Список ID посетителей
) {

    /**
     * Метод отмечает места как занятые посетителями.
     *
     * @param seatIds Список идентификаторов мест, которые будут отмечены как занятые.
     */
    fun markSeatsOccupiedByVisitors(seatIds: MutableList<Int>) {
        for (seatId in seatIds) {
            val seat = availableSeats.find { it.id == seatId && it.isOccupied }
            if (seat != null && !visitors.contains(seatId)) {
                visitors.add(seatId)
            } else {
                println("Ошибка: место с ID $seatId не может быть отмечено, так как не продано или уже отмечено посетителем!")
            }
        }
    }

    /**
     * Переопределенный метод для представления сеанса в виде строки.
     *
     * @return Строковое представление объекта `Session`.
     */
    override fun toString(): String {
        return "Session(id=$id, movieId=$movieId, startTime=$startTime, endTime=$endTime)"
    }

    /**
     * Метод создает копию текущего сеанса с возможностью изменения определенных полей.
     *
     * @param newMovieId Новый идентификатор фильма.
     * @param newStartTime Новое время начала сеанса.
     * @param newEndTime Новое время окончания сеанса.
     * @return Новый объект `Session` - копия текущего сеанса с измененными полями.
     */
    fun copy(
        newMovieId: Int = this.movieId,
        newStartTime: LocalDateTime = this.startTime,
        newEndTime: LocalDateTime = this.endTime
    ): Session {
        return Session(
            id,
            newMovieId,
            newStartTime,
            newEndTime,
            availableSeats.map { Seat(it.id, it.isOccupied) }.toMutableList()
        )
    }
}

/**
 * Класс `SessionManager` отвечает за управление сеансами в кинотеатре.
 *
 * @property database Экземпляр базы данных, в которой хранятся сведения о сеансах.
 */
class SessionManager(private val database: Database) {

    /**
     * Метод добавляет новый сеанс в базу данных.
     *
     * @param movieId Идентификатор фильма для нового сеанса.
     * @param startTime Время начала нового сеанса.
     */
    fun addSession(movieId: Int, startTime: LocalDateTime) {
        val id = database.sessionIdCounter++
        val movie = database.movies.find { it.id == movieId }
        if (movie != null) {
            val endTime =
                movie.let { startTime.toJavaLocalDateTime().plusMinutes(it.duration.toLong()).toKotlinLocalDateTime() }
            val availableSeats = (1..16).map { Seat(it) }.toMutableList()
            val newSession = Session(id, movieId, startTime, endTime, availableSeats)
            if (checkSessionTimeOverlap(newSession) && checkSessionDuration(newSession)) {
                database.sessions.add(newSession)
                println("Сеанс успешно добавлен!")
            } else {
                println("Сеанс пересекается с уже существующими сеансами!")
            }
        } else {
            println("Фильм с ID = $Int не найден!")
        }
    }

    /**
     * Метод редактирует существующий сеанс в базе данных.
     *
     * @param sessionId Идентификатор сеанса для редактирования.
     * @param movieId Новый идентификатор фильма для сеанса.
     * @param startTime Новое время начала сеанса.
     * @param endTime Новое время окончания сеанса.
     */
    fun editSession(sessionId: Int, movieId: Int, startTime: LocalDateTime, endTime: LocalDateTime) {
        val session = database.sessions.find { it.id == sessionId }
        val movie = database.movies.find { it.id == movieId }

        if (session != null && movie != null) {
            if (checkSessionTimeOverlap(session.copy(movieId, startTime, endTime)) &&
                checkSessionDuration(session.copy(movieId, startTime, endTime))
            ) {
                session.movieId = movieId
                session.startTime = startTime
                session.endTime = endTime
                println("Данные сеанса успешно обновлены!")
            } else {
                println("Сеанс пересекается с уже существующими сеансами или длительность сеанса некорректна!")
            }
        } else {
            println("Сеанс с ID $sessionId или фильм с ID $movieId не найдены!")
        }
    }

    /**
     * Метод проверяет пересечение времени нового сеанса с уже существующими сеансами.
     *
     * @param newSession Новый сеанс для проверки пересечения времени.
     * @return `true`, если новый сеанс не пересекается с другими; в противном случае - `false`.
     */
    private fun checkSessionTimeOverlap(newSession: Session): Boolean {
        for (existingSession in database.sessions) {
            if (existingSession.id != newSession.id && (newSession.startTime <= existingSession.endTime && newSession.startTime >= existingSession.startTime ||
                        newSession.endTime <= existingSession.endTime && newSession.endTime >= existingSession.startTime)
            ) {
                return false
            }
        }
        return true
    }

    /**
     * Метод проверяет корректность длительности сеанса.
     *
     * @param session Сеанс для проверки длительности.
     * @return `true`, если длительность сеанса корректна; в противном случае - `false`.
     */
    private fun checkSessionDuration(session: Session): Boolean {
        val movie = database.movies.find { it.id == session.movieId }
        if (movie != null) {
            val expectedEndTime =
                session.startTime.toJavaLocalDateTime().plusMinutes(movie.duration.toLong()).toKotlinLocalDateTime()
            return expectedEndTime == session.endTime
        }
        return false
    }

    /**
     * Метод отображает доступные места на указанном сеансе.
     *
     * @param sessionId Идентификатор сеанса для отображения мест.
     */
    fun displayAvailableSeats(sessionId: Int) {
        val session = database.sessions.find { it.id == sessionId }
        session?.let { s ->
            println("Места на сеансе ${s.id} (\u001B[32m свободные\u001B[0m и\u001B[31m занятые\u001B[0m ):")
            for (row in 1..4) {
                for (column in 1..4) {
                    val seat = session.availableSeats.find { it.id == (row - 1) * 4 + column }
                    if (seat != null) {
                        print("$seat")
                    }
                }
                println()
            }
        }
    }
}
