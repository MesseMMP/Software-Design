package org.example

import kotlinx.datetime.LocalDateTime
import java.util.*
import kotlin.system.exitProcess

/**
 * Представляет собой консольное приложение для взаимодействия с кинотеатром.
 *
 * @property database База данных, содержащая списки пользователей, билетов, сеансов и фильмов.
 * @property cinema Кинотеатр, осуществляющий взаимодействие с базой данных.
 * @property scanner Объект Scanner для чтения ввода пользователя.
 * @property currentUser Текущий пользователь, авторизованный в системе.
 */
class CinemaApplication(private val database: Database) {
    private val cinema: Cinema = Cinema(database)
    private val scanner = Scanner(System.`in`)
    private var currentUser: User? = null

    /**
     * Запускает главный цикл приложения.
     */

    fun run() {
        try {
            // Пробуем загрузить список сохраненных пользователей
            cinema.loadUsers()
            while (true) {
                if (currentUser == null) {
                    handleAuthentication()
                } else {
                    handleAuthorizedUserMenu()
                }
            }
        } catch (e: Exception) {
            println("Произошла непредвиденная ошибка: ${e.message}")
        }
    }

    /**
     * Обрабатывает процесс аутентификации пользователя.
     */

    private fun handleAuthentication() {
        println("=== Добро пожаловать в кинотеатр ===")
        println("1. Регистрация")
        println("2. Вход")
        println("0. Завершение работы программы")

        when (scanner.nextLine()) {
            "1" -> {
                handleUserRegistration()
            }

            "2" -> {
                handleUserLogin()
            }

            "0" -> {
                println("Программа завершена.")
                exitProcess(0)
            }

            else -> println("Некорректный ввод! Попробуйте еще раз!")
        }
    }

    /**
     * Обрабатывает процесс регистрации нового пользователя.
     */

    private fun handleUserRegistration() {
        println("Введите имя пользователя:")
        val username = scanner.nextLine()

        // Ввод пароля дважды для подтверждения
        println("Введите пароль:")
        val password1 = scanner.nextLine()

        println("Повторите ввод пароля:")
        val password2 = scanner.nextLine()

        if (password1 == password2) {
            cinema.registerUser(username, password1)
        } else {
            println("Пароли не совпадают. Регистрация отменена.")
        }
    }

    /**
     * Обрабатывает процесс входа пользователя в систему.
     */

    private fun handleUserLogin() {
        println("Введите имя пользователя:")
        val username = scanner.nextLine()
        println("Введите пароль:")
        val password = scanner.nextLine()
        if (cinema.loginUser(username, password)) {
            currentUser = database.users.find { it.username == username }
            println("Вход выполнен успешно!")
        } else {
            println("Ошибка входа! Проверьте имя пользователя и пароль!")
        }
    }

    /**
     * Обрабатывает главное меню авторизованного пользователя.
     */

    private fun handleAuthorizedUserMenu() {
        println("\n=== Меню пользователя ${currentUser?.username} ===")
        println("1. Добавить фильм")
        println("2. Добавить сеанс")
        println("3. Отредактировать фильм")
        println("4. Отредактировать сеанс")
        println("5. Показать свободные места на сеансе")
        println("6. Продать билет")
        println("7. Вернуть билет")
        println("8. Отметить занятые места посетителями на сеансе")
        println("9. Сохранить данные")
        println("10. Загрузить данные")
        println("0. Выйти из аккаунта")

        when (scanner.nextLine()) {
            "1" -> handleAddMovie()
            "2" -> handleAddSession()
            "3" -> handleEditMovie()
            "4" -> handleEditSession()
            "5" -> handleDisplayAvailableSeats()
            "6" -> handleSellTicket()
            "7" -> handleReturnTicket()
            "8" -> handleMarkSeatsOccupied()
            "9" -> handleSaveData()
            "10" -> handleLoadData()
            "0" -> {
                currentUser = null
                println("Выход выполнен успешно!")
            }

            else -> println("Некорректная команда! Попробуйте еще раз!")
        }
    }

    /**
     * Обрабатывает процесс добавления нового фильма в систему.
     */

    private fun handleAddMovie() {
        println("\n=== Добавление фильма ===")

        println("Список фильмов:")
        database.movies.forEach { println(it) }

        println("Введите название фильма:")
        val title = scanner.nextLine()
        println("Введите продолжительность фильма (в минутах):")

        val duration = try {
            scanner.nextInt()
        } catch (e: InputMismatchException) {
            println("Ошибка ввода! Введите корректное значение для продолжительности!")
            scanner.nextLine()
            return
        }

        scanner.nextLine()
        println("Введите жанр фильма:")
        val genre = scanner.nextLine()
        cinema.addMovie(title, duration, genre)
    }

    /**
     * Обрабатывает процесс добавления нового сеанса в систему.
     */

    private fun handleAddSession() {
        println("\n=== Добавление сеанса ===")

        println("Список фильмов:")
        database.movies.forEach { println(it) }

        println("\nСписок существующих сеансов:")
        database.sessions.forEach { println(it) }

        println("Введите ID фильма:")

        val movieId = try {
            scanner.nextInt()
        } catch (e: InputMismatchException) {
            println("Ошибка ввода! Введите корректное значение для ID фильма!")
            scanner.nextLine()
            return
        }
        scanner.nextLine()
        println("Введите дату и время начала сеанса в формате 'гггг-мм-ддTчч:мм':")
        val startTime = try {
            LocalDateTime.parse(scanner.nextLine())
        } catch (e: Exception) {
            println("Ошибка ввода! Введите корректное значение для даты и времени!")
            return
        }

        cinema.addSession(movieId, startTime)
    }

    /**
     * Обрабатывает процесс редактирования фильма.
     */

    private fun handleEditMovie() {
        println("\n=== Редактирование фильма ===")

        println("Список фильмов:")
        database.movies.forEach { println(it) }

        println("Введите ID фильма для редактирования:")
        val movieId = try {
            scanner.nextInt()
        } catch (e: InputMismatchException) {
            println("Ошибка ввода! Введите корректное значение для ID фильма!")
            scanner.nextLine()
            return
        }
        scanner.nextLine()

        println("Введите новое название фильма:")
        val newTitle = scanner.nextLine()

        println("Введите новую продолжительность фильма (в минутах):")
        val newDuration = try {
            scanner.nextInt()
        } catch (e: InputMismatchException) {
            println("Ошибка ввода! Введите корректное значение для продолжительности!")
            scanner.nextLine()
            return
        }
        scanner.nextLine()

        println("Введите новый жанр фильма:")
        val newGenre = scanner.nextLine()

        cinema.editMovie(movieId, newTitle, newDuration, newGenre)
    }

    /**
     * Обрабатывает процесс редактирования сеанса.
     */

    private fun handleEditSession() {
        println("\n=== Редактирование сеанса ===")

        println("Список существующих сеансов:")
        database.sessions.forEach { println(it) }

        println("Введите ID сеанса для редактирования:")
        val sessionId = try {
            scanner.nextInt()
        } catch (e: InputMismatchException) {
            println("Ошибка ввода! Введите корректное значение для ID сеанса!")
            scanner.nextLine()
            return
        }
        scanner.nextLine()

        println("Введите новый ID фильма:")
        val newMovieId = try {
            scanner.nextInt()
        } catch (e: InputMismatchException) {
            println("Ошибка ввода! Введите корректное значение для ID фильма!")
            scanner.nextLine()
            return
        }
        scanner.nextLine()

        println("Введите новую дату и время начала сеанса в формате 'гггг-мм-ддTчч:мм':")
        val newStartTime = try {
            LocalDateTime.parse(scanner.nextLine())
        } catch (e: Exception) {
            println("Ошибка ввода! Введите корректное значение для даты и времени!")
            return
        }

        println("Введите новую дату и время окончания сеанса в формате 'гггг-мм-ддTчч:мм':")
        val newEndTime = try {
            LocalDateTime.parse(scanner.nextLine())
        } catch (e: Exception) {
            println("Ошибка ввода! Введите корректное значение для даты и времени!")
            return
        }

        cinema.editSession(sessionId, newMovieId, newStartTime, newEndTime)
    }

    /**
     * Выводит список занятых и свободных мест на сеансе.
     */

    private fun handleDisplayAvailableSeats() {
        // Логика показа свободных мест на сеансе
        println("\n=== Свободные места на сеансе ===")

        println("\nСписок существующих сеансов:")
        database.sessions.forEach { println(it) }

        println("Введите ID сеанса:")

        val sessionId = try {
            scanner.nextInt()
        } catch (e: InputMismatchException) {
            println("Ошибка ввода! Введите корректное значение для ID сеанса!")
            scanner.nextLine()
            return
        }
        scanner.nextLine()
        cinema.displayAvailableSeats(sessionId)
    }

    /**
     * Обрабатывает процесс продажи билета на сеанс.
     */

    private fun handleSellTicket() {
        println("\n=== Продажа билета ===")

        println("\nСписок существующих сеансов:")
        database.sessions.forEach { println(it) }

        println("Введите ID сеанса:")

        val sessionId = try {
            scanner.nextInt()
        } catch (e: InputMismatchException) {
            println("Ошибка ввода! Введите корректное значение для ID сеанса!")
            scanner.nextLine()
            return
        }
        scanner.nextLine()

        cinema.displayAvailableSeats(sessionId)

        println("Введите ID места:")

        val seatId = try {
            scanner.nextInt()
        } catch (e: InputMismatchException) {
            println("Ошибка ввода! Введите корректное значение для ID места!")
            scanner.nextLine()
            return
        }
        scanner.nextLine()
        cinema.sellTicket(sessionId, seatId)
    }

    /**
     * Обрабатывает процесс возврата билета.
     */

    private fun handleReturnTicket() {
        println("\n=== Возврат билета ===")

        println("Список проданных билетов:")
        database.tickets.forEach { println(it) }

        println("Введите ID билета:")

        val ticketId = try {
            scanner.nextInt()
        } catch (e: InputMismatchException) {
            println("Ошибка ввода! Введите корректное значение для ID билета!")
            scanner.nextLine() // Очистка буфера после ошибки ввода
            return
        }
        scanner.nextLine()
        cinema.returnTicket(ticketId)
    }


    /**
     * Обрабатывает процесс отметки о прибытии посетителей на сеанс.
     */

    private fun handleMarkSeatsOccupied() {
        // Логика отметки занятых мест
        println("\n=== Отметка занятых мест ===")

        println("Список существующих сеансов:")
        database.sessions.forEach { println(it) }

        println("Введите ID сеанса:")
        val sessionId = try {
            scanner.nextInt()
        } catch (e: InputMismatchException) {
            println("Ошибка ввода! Введите корректное значение для ID сеанса!")
            scanner.nextLine()
            return
        }
        scanner.nextLine()

        cinema.displayAvailableSeats(sessionId)

        println("Введите количество посетителей:")
        val numberOfVisitors = try {
            scanner.nextInt()
        } catch (e: InputMismatchException) {
            println("Ошибка ввода! Введите корректное значение для количества посетителей!")
            scanner.nextLine()
            return
        }
        scanner.nextLine()

        val seatIds: MutableList<Int> = mutableListOf()

        for (i in 1..numberOfVisitors) {
            println("Введите номер билета для посетителя $i:")
            val ticketId = try {
                scanner.nextInt()
            } catch (e: InputMismatchException) {
                println("Ошибка ввода! Введите корректное значение для номера билета!")
                scanner.nextLine()
                return
            }
            scanner.nextLine()

            val ticket = database.tickets.find { it.id == ticketId && it.sessionId == sessionId }
            if (ticket != null) {
                seatIds.add(ticket.seatId)
            } else {
                println("Билет с номером $ticketId не найден для сеанса $sessionId!")
                return
            }
        }

        val session: Session? = database.sessions.find { it.id == sessionId }

        session?.markSeatsOccupiedByVisitors(seatIds)

    }

    /**
     * Обрабатывает процесс сериализации данных.
     */

    private fun handleSaveData() {
        println("1. Сохранить данные о фильмах")
        println("2. Сохранить данные о сеансах")
        println("3. Сохранить данные о билетах")
        println("4. Сохранить данные о пользователях")
        println("5. Сохранить все данные")
        when (scanner.nextLine()) {
            "1" -> cinema.saveMovies()
            "2" -> cinema.saveSessions()
            "3" -> cinema.saveTickets()
            "4" -> cinema.saveUsers()
            "5" -> {
                cinema.saveMovies()
                cinema.saveSessions()
                cinema.saveTickets()
                cinema.saveUsers()
            }

            else -> println("Некорректный ввод!")
        }
        println("Данные успешно сохранены!")
    }

    /**
     * Обрабатывает процесс десериализации данных.
     */

    private fun handleLoadData() {
        // Загрузка данных
        println("1. Загрузить данные о фильмах")
        println("2. Загрузить данные о сеансах")
        println("3. Загрузить данные о билетах")
        println("4. Загрузить данные о пользователях")
        println("5. Загрузить все данные")
        when (scanner.nextLine()) {
            "1" -> cinema.loadMovies()
            "2" -> cinema.loadSessions()
            "3" -> cinema.loadTickets()
            "4" -> cinema.loadUsers()
            "5" -> {
                cinema.loadMovies()
                cinema.loadSessions()
                cinema.loadTickets()
                cinema.loadUsers()
            }

            else -> println("Некорректный ввод!")
        }
    }
}
